-- ===============================================
-- 📊 Azure Cost Dataset — SQL Exploration & Analysis
-- ===============================================

-- 🔍 INITIAL DATA VALIDATION
-- ---------------------------

-- 🔹 0. Total number of records
SELECT COUNT(*) AS TotalRecords FROM costs;

-- 🔹 1. Preview sample records
SELECT * FROM costs LIMIT 5;

-- 🔹 2. List column names and data types
DESCRIBE costs;

-- 🔹 3. NULL Count Checks (Tagging + Cost)
SELECT COUNT(*) AS NullResourceGroups FROM costs WHERE ResourceGroup IS NULL;
SELECT COUNT(*) AS NullMeterCategories FROM costs WHERE MeterCategory IS NULL;
SELECT COUNT(*) AS NullCosts FROM costs WHERE CostInBillingCurrency IS NULL;

-- ===============================================
-- 💰 CORE COST ANALYSIS
-- ===============================================

-- 🔹 4. Total Cost Across All Records
-- Used to benchmark percentages and support Insight 1 + Insight 4
SELECT 
    SUM(CostInBillingCurrency) AS TotalCost
FROM costs;

-- 🔹 5. Cost by Service Category (MeterCategory)
-- ✅ Insight 1: Top 3 services account for ~45% of total cost
SELECT 
    MeterCategory,
    SUM(CostInBillingCurrency) AS TotalCost
FROM costs
GROUP BY MeterCategory
ORDER BY TotalCost DESC;

-- 🔹 6. Cost by Region (ResourceLocation)
-- ✅ Insight 2: Westeurope region dominates total spend
SELECT 
    ResourceLocation,
    SUM(CostInBillingCurrency) AS TotalCost
FROM costs
GROUP BY ResourceLocation
ORDER BY TotalCost DESC;

-- 🔹 7. Cost by Resource Group
-- Reveals team/project-based ownership of cost
SELECT 
    ResourceGroup,
    SUM(CostInBillingCurrency) AS TotalCost
FROM costs
GROUP BY ResourceGroup
ORDER BY TotalCost DESC;

-- 🔹 8. Cost by SKU / Meter Name
-- Drilldown to specific resources/SKUs costing the most
SELECT 
    MeterName,
    SUM(CostInBillingCurrency) AS TotalCost
FROM costs
GROUP BY MeterName
ORDER BY TotalCost DESC;

-- 🔹 9. Daily Cost Trend
-- ✅ Insight 5: Overall trend shows no sharp anomalies
SELECT 
    Date,
    SUM(CostInBillingCurrency) AS DailyTotal
FROM costs
GROUP BY Date
ORDER BY Date;

-- 🔹 10. Daily Cost Volatility (optional)
-- ✅ Insight 5 (continued): Confirming stability via STDDEV
SELECT 
    STDDEV(SUM(CostInBillingCurrency)) OVER () AS DailyCostStdDev
FROM costs
GROUP BY Date;

-- 🔹 11. Services with High Cost Volatility
-- Helps identify unstable services for potential review
SELECT 
    MeterCategory,
    AVG(CostInBillingCurrency) AS AvgCost,
    STDDEV(CostInBillingCurrency) AS CostVolatility
FROM costs
GROUP BY MeterCategory
ORDER BY CostVolatility DESC;

-- 🔹 12. Pareto Analysis: Top 10 Service Categories by Cost
-- ✅ Insight 4: 80% of total cost is driven by 13 MeterCategories
SELECT 
    MeterCategory,
    SUM(CostInBillingCurrency) AS TotalCost
FROM costs
GROUP BY MeterCategory
ORDER BY TotalCost DESC
LIMIT 13;

-- 🔹 13. Unassigned or Null Locations — Tagging Check
-- ✅ Insight 3: ~$1,400 of cost is 'Unassigned'
SELECT 
    ResourceLocation,
    COUNT(*) AS RecordCount,
    SUM(CostInBillingCurrency) AS TotalCost
FROM costs
WHERE ResourceLocation IS NULL OR ResourceLocation = 'Unassigned'
GROUP BY ResourceLocation;

-- ===============================================


